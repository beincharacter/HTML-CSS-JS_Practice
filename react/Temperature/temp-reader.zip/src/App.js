import logo from './logo.svg';
import './App.css';
import { TempBody } from './Componant/mainBody';

function App() {
  return (
    <div className="App">
      <TempBody/>
    </div>
  );
}

export default App;
